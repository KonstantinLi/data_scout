@echo off
REM Check if Docker is installed
docker --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo Docker is not installed. Please install Docker.
    exit /b 1
)

REM Check if docker-compose.yml exists in the current directory
IF NOT EXIST docker-compose.yml (
    echo docker-compose.yml not found in the current directory.
    exit /b 1
)

REM Run docker-compose up
docker-compose up -d

IF %ERRORLEVEL% EQU 0 (
    echo CSC Engine has been deployed successfully in localhost:8081. Enjoy!
) ELSE (
    echo Failed to deploy CSC Engine.
    exit /b 1
)