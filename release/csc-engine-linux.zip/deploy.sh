#!/bin/bash

# Check if Docker is installed
if ! command -v docker &> /dev/null
then
    echo "Docker is not installed. Please install Docker."
    exit 1
fi

# Check if docker-compose is installed
if ! command -v docker-compose &> /dev/null
then
    echo "Docker Compose is not installed. Please install Docker Compose."
    exit 1
fi

# Check if docker-compose.yml exists in the current directory
if [ ! -f "docker-compose.yml" ]; then
    echo "docker-compose.yml not found in the current directory."
    exit 1
fi

# Run docker-compose up
docker-compose up -d

if [ $? -eq 0 ]; then
    echo "CSC Engine has been deployed successfully in localhost:8081. Enjoy!"
else
    echo "Failed to deploy CSC Engine."
    exit 1
fi
